# Powder

This plugin provides completion for [powder](https://github.com/powder-rb/powder/).

To use it, add powder to the plugins array of your zshrc file:
```
plugins=(... powder)
```
